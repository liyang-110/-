/*
var conn = new WebIM.connection({
    https: typeof WebIM.config.https === 'boolean' ? WebIM.config.https : location.protocol === 'https:',
    url: WebIM.config.xmppURL,
    isAutoLogin: WebIM.config.isAutoLogin,
    isMultiLoginSessions: WebIM.config.isMultiLoginSessions,
    heartBeatWait: WebIM.config.heartBeatWait,
    autoReconnectNumMax: WebIM.config.autoReconnectNumMax,
    autoReconnectInterval: WebIM.config.autoReconnectInterval,
    apiUrl: WebIM.config.apiURL,
    isHttpDNS: WebIM.config.isHttpDNS,
    isWindowSDK: WebIM.config.isWindowSDK
});
*/
var conn = new WebIM.connection({
    isMultiLoginSessions: WebIM.config.isMultiLoginSessions,
    https: typeof WebIM.config.https === 'boolean' ? WebIM.config.https : location.protocol === 'https:',
    url: WebIM.config.xmppURL,
    heartBeatWait: WebIM.config.heartBeatWait,
    autoReconnectNumMax: WebIM.config.autoReconnectNumMax,
    autoReconnectInterval: WebIM.config.autoReconnectInterval,
    apiUrl: WebIM.config.apiURL,
    isHttpDNS: WebIM.config.isHttpDNS,
    isWindowSDK: WebIM.config.isWindowSDK,
    isAutoLogin: WebIM.config.isAutoLogin
});
conn.listen({
    onOpened: function ( message ) {          //连接成功回调
        // 如果isAutoLogin设置为false，那么必须手动设置上线，否则无法收消息
        // 手动上线指的是调用conn.setPresence(); 如果conn初始化时已将isAutoLogin设置为true
        // 则无需调用conn.setPresence();  
        console.info("conn ok");
    },  
    onClosed: function ( message ) {
    	
    },         //连接关闭回调
    onTextMessage: function ( message ) {
    	var scope = angular.element('#chatEle').scope();
    	scope.receivedText( message );
    	scope.$apply();
    },    //收到文本消息
    onEmojiMessage: function ( message ) {},   //收到表情消息
    onPictureMessage: function ( message ) {}, //收到图片消息
    onCmdMessage: function ( message ) {
    	console.log( message );
    	if( 'status'==message.action ){
    		
    	}
    },     //收到命令消息
    onAudioMessage: function ( message ) {
    	console.log( "received audio message ");
    	//IMCall.init();
    },   //收到音频消息
    onLocationMessage: function ( message ) {},//收到位置消息
    onFileMessage: function ( message ) {},    //收到文件消息
    onVideoMessage: function (message) {
    var node = document.getElementById('privateVideo');
    var option = {
            url: message.url,
            headers: {
              'Accept': 'audio/mp4'
            },
            onFileDownloadComplete: function (response) {
                var objectURL = WebIM.utils.parseDownloadResponse.call(conn, response);
                node.src = objectURL;
            },
            onFileDownloadError: function () {
                console.log('File down load error.')
            }
        };
        WebIM.utils.download.call(conn, option);
    },   //收到视频消息
    onPresence: function ( message ) {},       //收到联系人订阅请求、处理群组、聊天室被踢解散等消息
    onRoster: function ( message ) {},         //处理好友申请
    onInviteMessage: function ( message ) {},  //处理群组邀请
    onOnline: function () {
    	console.log("onOnline");
    },                  //本机网络连接成功
    onOffline: function () {
    	console.log("onOffline");
    },                 //本机网络掉线
    onError: function ( message ) {
    	console.log("conn error");
    },          //失败回调
    onBlacklistUpdate: function (list) {       //黑名单变动
        // 查询黑名单，将好友拉黑，将好友从黑名单移除都会回调这个函数，list则是黑名单现有的所有好友信息
        console.log(list);
    }
});
var IMCall = {
	rtcCall : '',
	init : function(){
		console.log("rtcCall init...");
		
		this.rtcCall = new WebIM.WebRTC.Call({
		    connection: conn,
		    mediaStreamConstaints: {
		            audio: true,
		            video: true
		    },
		    listener: {
		        onAcceptCall: function (from, options) {
		        	console.log("================ onAcceptCall =========================");
		        	console.log('onAcceptCall::', 'from: ', from, 'options: ', options);
		        	//等待接听
		        },
		        onGotRemoteStream: function (stream) {
		        	console.log("============= onGotRemoteStream =======================");
		            console.log('onGotRemoteStream::', 'stream: ', stream);
		        	var video = document.getElementById('remoteVideo');
		        	video.src = window.URL.createObjectURL(stream);
		        },
		        onGotLocalStream: function (stream) {
		        	console.log("============= onGotLocalStream =========================");
		            console.log('onGotLocalStream::', 'stream:', stream);
		            var video = document.getElementById('localVideo');
		            video.src = window.URL.createObjectURL(stream);
		        },
		        onRinging: function (caller) {
		        	console.log("================== onRinging ============================");
		            console.log('onRinging::', 'caller:', caller);
		        	var scope = angular.element('#chatEle').scope();
		        	scope.onRinging = true ;
		        	scope.currentVideoSession = caller;
		        	scope.$apply();
		        },
		        onTermCall: function (reason) {
		        	var scope = angular.element('#chatEle').scope();
		        	// scope.onVideo = false ;
		        	scope.currentVideoSession = '';
		        	scope.$apply();
		        	console.log("================== onTermCall ============================");
		            console.log('onTermCall::');
		            console.log('reason:', reason);
		        },
		        onIceConnectionStateChange: function (iceState) {
		        	console.log("============ onIceConnectionStateChange =====================");
		            console.log('onIceConnectionStateChange::', 'iceState:', iceState);
		            if( 'connected'==iceState){
		            	console.log("connected");
		            }else if('closed'==iceState){
		            	console.log("closed");
		            }else if('checking'==iceState){
		            	console.log("checking");
		            }
		        },
		        onError: function (e) {
		        	console.log("======================== onError =============================");
		        	console.log(e);
		        	console.log( e.name );
		        }
		     }
		});
	},
	call : function ( callerId, toId ) {
		 this.rtcCall.caller = callerId ;
		 this.rtcCall.makeVideoCall( toId );
	},
	endCall : function () {
	 	this.rtcCall.endCall();
	},
	acceptCall : function () {
	 	this.rtcCall.acceptCall();
	}
};
var options = { 
	apiUrl: WebIM.config.apiURL,
	user: easemobUser,
	pwd: easemobPass,
	appKey: WebIM.config.appkey
};
if( easemobUser && easemobUser.indexOf('hx_')==0 ){
	console.log("options");
	console.log( options );
	conn.open(options);
	IMCall.init();
}
function IM_closeControl(){
	$("#chat").removeClass("show");
}
function IM_contact( id,img,name ){
	if( !id || id.indexOf('hx_')!=0 ){
		alert("错误");
		return;
	}else if( IMStorage.check()==false ){
		alert("您的浏览器不支持此功能");
		return;
	}
	var scope = angular.element('#chatEle').scope();
	scope.onChat = true;
	scope.sessionUser = {
			id : id,
			img : img,
			name : name 
	};
	if( scope.userList.length>0 ){
		for(var i=0,len = scope.userList.length;i<len;i++){
			if( scope.userList[i].id == scope.sessionUser.id ){
				scope.userList[i] = scope.sessionUser;
				break;
			}else if( i==len-1 ){
				scope.userList.push( scope.sessionUser );
				var im = IMStorage.fetch();
				im.userList = scope.userList;
				IMStorage.save( im );
			}
		}
	}else{
		scope.userList.push( scope.sessionUser );
		var im = IMStorage.fetch();
		im.userList = scope.userList;
		IMStorage.save( im );
	}
	scope.select( scope.sessionUser.id );
	scope.$apply();
	return;
}
function IM_sendMessage( fromObj , to , message ){
    var id = conn.getUniqueId();                 // 生成本地消息id
    var msg = new WebIM.message('txt', id);      // 创建文本消息
    msg.set({
        msg:message,                  // 消息内容
        to: to ,                          // 接收消息对象（用户id）
        roomType: false,
        ext : fromObj ,
        success: function (id, serverMsgId) {
            console.log('send private text Success');
        }
    });
    msg.body.chatType = 'singleChat';
    conn.send(msg.body);
}
function IM_messagesScorllTop(){
	var m_message = $("#chat .m-message");
	m_message.scrollTop(m_message.find("ul").height());
}
var storeKey = "CHAT-DATA-"+ easemobUser;
var now = new Date();
var IMStorage = {
	state : {
			user : {
				id : 1,
				name : "Coffce",
				img : "dist/images/1.jpg"
			},
			userList : [],
			sessionList : []
	},
	check : function(){
		return localStorage && localStorage.getItem && localStorage.setItem ;
	},
	init : function() {
		var data = localStorage.getItem( storeKey );
		if( data ) {
			IMStorage.state = data;
		}else{
			localStorage.setItem( storeKey , JSON.stringify( IMStorage.state ) );
		}
	},
	fetch : function() {
		IMStorage.state =  JSON.parse(localStorage.getItem(storeKey));
		return IMStorage.state;
	},
	save : function( data ){
		localStorage.setItem(storeKey, JSON.stringify( data ));
	}
};
$.fn.extend({
    /**
     * ctrl+enter提交表单
     * @param {Function} fn 操作后执行的函数
     * @param {Object} thisObj 指针作用域
     */
    ctrlSubmit:function(fn,thisObj){
        var obj = thisObj || this;
        var stat = false;
        return this.each(function(){
            $(this).keyup(function(event){
                //只按下ctrl情况，等待enter键的按下
                if(event.keyCode == 17){
                    stat = true;
                    //取消等待
                    setTimeout(function(){
                        stat = false;
                    },300);
                }  
                if(event.keyCode == 13 && (stat || event.ctrlKey)){
                    fn.call(obj,event);
                }  
            });
        });
    }
});
$(function(){
	$("#chat-m-text-textarea").ctrlSubmit(function(event){
		var scope = angular.element('#chatEle').scope();
		scope.chat.send();
		scope.$apply();
	});
});
var app=angular.module('ngChatApp', []);
app.directive('repeatfinish',function(){
    return {
    	restrict: 'E',
        link: function(scope,element,attr){
            if(scope.$last == true){
               scope.$eval( attr.link );
            }
        }
    }
});
app.filter('search', function () {
    return function (collection, keyname) {  
        var output = [];
        angular.forEach(collection, function (item) {
        	if (item.name.indexOf(keyname) != -1) {  
                output.push(item);  
            } 
        });  
        return output;  
    }
});  
app.controller('ngChatCtrl',['$scope',function ($scope) {
  $scope.currentVideoSession = '';
  $scope.onRinging = false;
  $scope.onChat = false;
  $scope.onVideo = false;
  $scope.renderFinish = function(){
	  IM_messagesScorllTop();
  };
  $scope.user = {
		  id : easemobUser,
		  img : easemobHead,
		  name : easemobName
  };
  $scope.sessionUser = {
		  id :'',
		  img :'',
		  name:'',
  }
  $scope.userList = [];
  // 过滤出只包含这个key的会话
  $scope.filterKey ='';
  //当前会话
  $scope.session = {
		  userId: '',
		  messages : []
  };
  $scope.filters = {
      avatar: function(e) {
          var t = e.self ? $scope.user : $scope.sessionUser;
          if( t && t.img ){
        	  return '/upload/headpic/'+t.img;
          }else{
        	  return '/static/images/personal_center/user.png';
          }
      },
      time: function(e) {
          return "string" == typeof e && (e = new Date(e)), e.getHours() + ":" + e.getMinutes();
      }
  },
  $scope.init = function(){
	  IMStorage.init();
	  var im = IMStorage.fetch();
	  $scope.userList = im.userList;
	  if( $scope.userList.length>0 ){
		  $scope.sessionUser = $scope.userList[0];
		  $scope.select( $scope.session.userId );
	  }
  };
  $scope.select = function( selectId ){
	  var im = IMStorage.fetch();
	  $scope.session = {
			  userId: selectId ,
			  messages : []
	  };
	  im.sessionList.filter(function(elt, i, array) {
	  	  if( elt.userId == selectId ){
	  		$scope.session = elt;
	  		return true;
	  	  }else{
	  		return false;
	  	  }
	  });
	  $scope.userList.filter(function(elt, i, array) {
  			if( elt.id == selectId ){
  				$scope.sessionUser = elt;
  				return true;
  			}
  	  });
  };
  $scope.inputText='';
  $scope.chat = {
	  show : function(){
		  $scope.onChat=true;
	  },
	  close : function(){
		  $scope.onChat=false;
	  },
	  send : function(){
		  if( $scope.inputText ){
			  $scope.send( $scope.inputText );
			  $scope.inputText='';
		  }
	  }
  };
  $scope.send = function( msg ){
	  IM_sendMessage( $scope.user, $scope.session.userId , msg );
	  $scope.session.messages.push({
			text: msg,
            date: new Date,
            self: !0
	  });
	  IM_messagesScorllTop();
	  $scope.save();
  };
  $scope.save = function(){
	  var im = IMStorage.fetch();
	  if( im.sessionList.length>0 ){
		  for(var i=0, len=im.sessionList.length; i<len; i++) {
		        if ( im.sessionList[i].userId == $scope.session.userId ) { 
		            im.sessionList[i]=$scope.session;
		            break;    // 循环被终止 
		        }else if( i==len-1 ){
		        	im.sessionList.push( $scope.session );
		        }
		  }
	  }else{
		  im.sessionList.push( $scope.session );
	  }
	  IMStorage.save( im );
  };
  $scope.addMessage = function( fromId, toId, msg ){
	  if( fromId == $scope.session.userId ){
		  var session = $scope.session;
		  session.messages.push({
				text: msg,
	            date: new Date,
	            self: fromId===$scope.user.id
		  });
		  $scope.session={};
		  $scope.session = session;
		  $scope.save();
	  }else{
		  var session = {
				  userId : fromId,
				  messages : [{
						text: msg,
			            date: new Date,
			            self: fromId===$scope.user.id
				  }]
		  };
		  var im = IMStorage.fetch();
		  if( im.sessionList.length>0 ){
			  for(var i=0, len=im.sessionList.length; i<len; i++) {
				  console.log( i );
			        if ( im.sessionList[i].userId == fromId ) { 
			            im.sessionList.messages.push(session.messages[0] );
			            break;    // 循环被终止 
			        }else if( i==len-1 ){
			        	im.sessionList.push( session );
			        }
			  }
		  }else{
			  im.sessionList.push( session );
		  }
		  IMStorage.save( im );
	  }
  };
  $scope.addUser = function( user ){
	  console.log("addUser");
	  console.log(  user );
	  if( $scope.sessionUser.id==''){
		  $scope.sessionUser = user;
	  }
	  if( $scope.session.userId == ''){
		  $scope.session.userId = user.id;
	  }
	  if( $scope.userList.length>0 ){
			for(var i=0,len = $scope.userList.length;i<len;i++){
				if( $scope.userList[i].id == user.id ){
					break;
				}else if( i==len-1 ){
					$scope.userList.push( user );
					var im = IMStorage.fetch();
					im.userList = $scope.userList;
					IMStorage.save( im );
				}
			}
		}else{
			$scope.userList.push( user );
			var im = IMStorage.fetch();
			im.userList = $scope.userList;
			IMStorage.save( im );
		}
	  console.log("addUser finished");
  };
  $scope.receivedText = function( message ){
	  console.log( "scope.receivedText" );
	  console.log( message );
	  var fromUser = {
			  id:message.ext.id,
			  ing:message.ext.img,
			  name:message.ext.name
	  }
	  $scope.addUser( fromUser );
	  $scope.addMessage(message.from,message.to, message.data );
	  $scope.onChat=true;
  };
  $scope.call = function(){
	  $scope.onChat = false;
	  $scope.onVideo = true;
	  //$("#video").show();
	  var callerId = $scope.user.id;
	  var toId = $scope.sessionUser.id;
	  IMCall.call(callerId, toId);
  };
  $scope.acceptCall = function(){
	  $scope.onChat = false;
	  $scope.onRinging = false;
	  $scope.onVideo = true;
	  IMCall.acceptCall();
	  //$("#video").show();
  };
  $scope.endCall = function(){
	  $scope.currentVideoSession = '';
	  $scope.onRinging = false;
	  $scope.onVideo = false;
	  //$("#video").hide();
	  IMCall.endCall();
  };
  $scope.init();
  $("#chat-container").addClass("show");
}]);